#ifndef __APRINTF_H
#define __APRINTF_H

char *aprintf(char **, const char *, ...);

#endif /* __APRINTF_H */
