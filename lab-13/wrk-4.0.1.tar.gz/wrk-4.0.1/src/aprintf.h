#ifndef APRINTF_H
#define APRINTF_H

char *aprintf(char **, const char *, ...);

#endif /* APRINTF_H */
